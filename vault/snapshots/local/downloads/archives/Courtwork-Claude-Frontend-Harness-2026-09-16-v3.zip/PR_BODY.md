# Claude 串行前端/Harness 施工登记 · v3

## 用户结果

完成一条真实、可检查、可中断、可接续的 Harness 工作路径；公共 grammar 和文字统一；删除没有独立价值的按钮和卡片。右侧用于当前对象阅读与判断，不常驻陈列 Runtime 资源数量。

## v3 增量

- 移除默认 Runtime inventory 卡与无任务空卡，保留 Settings、真实 Review、权限和查回。
- 消费官方 DeepSeek Harness 固定源码中的 sequence 概览、精简记录、选中项详情、具名工具输出和稳定阅读行为。
- 对象驱动的文件/差异/检查工作面；真实时间图按事实和任务开放，不引入完整 docking、调用大图或第二 trace store。
- 先判定入口价值，必要能力再反推后端；不为保住一个卡片造统计服务。

## 合流范围

新增本包 sidebar-trace-review.md，修订本包 README；完整安装补丁沿用前版两份索引登记及入口清理增补。RD-006→DF-04 与 00→13 串行顺序保持。产品代码由 Claude 接单后施工，本文不是能力验收。

## 核查

对 Courtwork f76dd7ec 与 DeepSeek Harness 0d1f5000 的相关源码及官方文档进行定点读取。完整补丁与 v2 增量均在精确文件快照上通过 git apply --check、实际应用与目标字节比对。产品测试、完整仓库链接检查、浏览器/真实200%未运行；无远端 PR 或部署。
