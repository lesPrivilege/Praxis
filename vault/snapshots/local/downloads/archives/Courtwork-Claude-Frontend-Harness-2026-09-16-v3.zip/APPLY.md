# v3 本地入账

主入口仍是 `engineering/execution/claude-frontend-harness-2026-09-16/README.md`。v3 包含 v2 的完整内容与新增 `sidebar-trace-review.md`：右栏 Runtime 统计卡退出默认工作面、DSH 顺序轨迹与选中项检查的消费边界，以及对应串行验收。

## 尚未应用前版

在独立工作树核对 AGENTS/current、HEAD、dirty paths 和在途修改后，使用 `Courtwork-Claude-Frontend-Harness-2026-09-16-v3.patch`。它修改原两份索引并新增本包三份文档；不修改产品代码。

```sh
PATCH=/absolute/path/Courtwork-Claude-Frontend-Harness-2026-09-16-v3.patch
git apply --check "$PATCH"
git apply "$PATCH"
node tools/check-doc-links.mjs
git diff --check
```

## 已应用 v2

仅使用 `Courtwork-Claude-Frontend-Harness-2026-09-16-v2-to-v3.patch`。它修改本包 README、新增右栏增补，入口清理文档与两个索引保持原字节。

```sh
PATCH=/absolute/path/Courtwork-Claude-Frontend-Harness-2026-09-16-v2-to-v3.patch
git apply --check "$PATCH"
git apply "$PATCH"
node tools/check-doc-links.mjs
git diff --check
```

两种补丁不要同时应用。若只应用了 v1，先用原 v2 包中的 v1-to-v2 补丁，再用本包增量。已有他人增量时保留最新内容，在原工单合并新增要求；不强行覆盖或 reset/stash 共享工作树。

本包相对链接按仓库落点解释；ZIP 顶层不是完整仓库。`verification.json` 只记录文档来源与独立文件快照上的补丁校验。未运行产品或浏览器，未创建远端 PR、更新 main 或部署。两个研究基线都在2026-09-16重新读取；实际施工仍核最新 HEAD。
